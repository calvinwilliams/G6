#include "G6.h"

int WorkerProcess( struct ServerEnv *penv )
{
	unsigned long		n ;
	//struct epoll_event	event ;
	
	int			nret = 0 ;
	
	/* ������־����ļ� */
	InfoLog( __FILE__ , __LINE__ , "--- G6.WorkerProcess ---" );
	
	/* ����ת�����߳� */
	penv->forward_thread_index = NULL ;
	for( n = 0 ; n < penv->cmd_para.forward_thread_size ; n++ )
	{
		while( penv->forward_thread_index ) sleep(1);
		
		penv->forward_thread_index = (int*)malloc( sizeof(int) ) ;
		if( penv->forward_thread_index == NULL )
		{
			ErrorLog( __FILE__ , __LINE__ , "malloc failed , errno[%d]" , errno );
			return -1;
		}
		*(penv->forward_thread_index) = n ;
		
		nret = pthread_create( penv->forward_thread_tid_array+n , NULL , & _ForwardThread , (void*)penv ) ;
		if( nret )
		{
			ErrorLog( __FILE__ , __LINE__ , "pthread_create forward thread failed , errno[%d]" , errno );
			return -1;
		}
		else
		{
			InfoLog( __FILE__ , __LINE__ , "parent_thread : [%lu] pthread_create [%lu]" , pthread_self() , penv->forward_thread_tid_array[n] );
		}
	}
	
	_AcceptThread( (void*)penv );
	
	return 0;
}

