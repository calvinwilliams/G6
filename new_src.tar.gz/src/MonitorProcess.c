#include "G6.h"

static char	g_exit_flag = 0 ;

extern struct ServerEnv	*g_penv ;

static void signal_proc( int sig_no )
{
	if( sig_no == SIGUSR1 )
	{
		pid_t	pid ;
		
		pid = fork() ;
		if( pid == -1 )
		{
			return;
		}
		else if( pid == 0 )
		{
			char	value[ 20 + 1 ] ;
			
			memset( value , 0x00 , sizeof(value) );
			snprintf( value , sizeof(value)-1 , "%lu" , (unsigned long)getpid() );
			setenv( "G6_PPID" , value , 1 );
			
			memset( value , 0x00 , sizeof(value) );
			snprintf( value , sizeof(value)-1 , "%p" , g_penv );
			setenv( "G6_PENV" , value , 1 );
			
			execvp( "G6" , g_penv->argv );
			exit(9);
		}
	}
	else if( sig_no == SIGUSR2 )
	{
		g_exit_flag = 1 ;
	}
	
	return;
}

int MonitorProcess( struct ServerEnv *penv )
{
	struct epoll_event	event ;
	
	int			status ;
	
	int			nret = 0 ;
	long			lret = 0 ;
	
	/* ������־����ļ� */
	InfoLog( __FILE__ , __LINE__ , "--- G6.MonitorProcess ---" );
	
	/* �����źž�� */
	signal( SIGCLD , SIG_DFL );
	signal( SIGCHLD , SIG_DFL );
	signal( SIGPIPE , SIG_IGN );
	signal( SIGUSR1 , signal_proc );
	signal( SIGUSR2 , signal_proc );
	
	/* ������ѭ�� */
	while( g_exit_flag == 0 )
	{
		/* �����ܵ� */
		_PIPE :
		nret = pipe( penv->accept_pipe.fds ) ;
		if( nret == -1 )
		{
			if( errno == EINTR )
				goto _PIPE;
			
			ErrorLog( __FILE__ , __LINE__ , "pipe failed , errno[%d]" , errno );
			return -1;
		}
		
		/* ���ܵ����˼��뵽�����˿�epoll�� */
		memset( & event , 0x00 , sizeof(event) );
		event.data.ptr = NULL ;
		event.events = EPOLLIN | EPOLLERR ;
		epoll_ctl( penv->accept_epoll_fd , EPOLL_CTL_ADD , penv->accept_pipe.fds[0] , & event );
		
		/* �����ӽ��� */
		_FORK :
		penv->pid = fork() ;
		if( penv->pid == -1 )
		{
			if( errno == EINTR )
				goto _FORK;
			
			ErrorLog( __FILE__ , __LINE__ , "fork failed , errno[%d]" , errno );
			close( penv->accept_pipe.fds[0] );
			close( penv->accept_pipe.fds[1] );
			return -1;
		}
		else if( penv->pid == 0 )
		{
			InfoLog( __FILE__ , __LINE__ , "child : [%ld]fork[%ld]" , getppid() , getpid() );
			
			nret = WorkerProcess( penv ) ;
			close( penv->accept_pipe.fds[0] );
			exit(-nret);
		}
		else
		{
			close( penv->accept_pipe.fds[1] );
			InfoLog( __FILE__ , __LINE__ , "parent : [%ld]fork[%ld]" , getpid() , penv->pid );
		}
		
		/* ����ӽ��̽��� */
		_WAITPID :
		lret = waitpid( penv->pid , & status , 0 );
		if( lret == -1 )
		{
			if( errno == EINTR )
				goto _WAITPID;
			
			ErrorLog( __FILE__ , __LINE__ , "waitpid failed , errno[%d]" , errno );
			close( penv->accept_pipe.fds[0] );
			close( penv->accept_pipe.fds[1] );
			return -1;
		}
		
		close( penv->accept_pipe.fds[0] );
		close( penv->accept_pipe.fds[1] );
		
		InfoLog( __FILE__ , __LINE__
			, "waitpid[%ld] WEXITSTATUS[%d] WIFSIGNALED[%d] WTERMSIG[%d] WCOREDUMP[%d]"
			, penv->pid , WEXITSTATUS(status) , WIFSIGNALED(status) , WTERMSIG(status) , WCOREDUMP(status) );
		
		/* �����ӽ��� */
		sleep(1);
	}
	
	return 0;
}

int _MonitorProcess( void *pv )
{
	return MonitorProcess( (struct ServerEnv *)pv );
}

