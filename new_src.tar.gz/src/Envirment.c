#include "G6.h"

int InitEnvirment( struct ServerEnv *penv )
{
	int		n ;
	
	penv->accept_epoll_fd = epoll_create( 1024 );
	if( penv->accept_epoll_fd == -1 )
	{
		printf( "epoll_create failed , errno[%d]" , errno );
		return -1;
	}
	
	penv->forward_thread_tid_array = (pthread_t *)malloc( sizeof(pthread_t) * penv->cmd_para.forward_thread_size ) ;
	if( penv->forward_thread_tid_array == NULL )
	{
		printf( "malloc failed , errno[%d]" , errno );
		return -1;
	}
	memset( penv->forward_thread_tid_array , 0x00 , sizeof(pthread_t) * penv->cmd_para.forward_thread_size );
	
	penv->forward_epoll_fd_array = (int *)malloc( sizeof(int) * penv->cmd_para.forward_thread_size ) ;
	if( penv->forward_epoll_fd_array == NULL )
	{
		printf( "malloc failed , errno[%d]" , errno );
		return -1;
	}
	memset( penv->forward_epoll_fd_array , 0x00 , sizeof(int) * penv->cmd_para.forward_thread_size );
	
	for( n = 0 ; n < penv->cmd_para.forward_thread_size ; n++ )
	{
		penv->forward_epoll_fd_array[n] = epoll_create( 1024 );
		if( penv->forward_epoll_fd_array[n] == -1 )
		{
			printf( "epoll_create failed , errno[%d]" , errno );
			return -1;
		}
	}
	
	penv->forward_session_array = (struct ForwardSession *)malloc( sizeof(struct ForwardSession) * penv->cmd_para.forward_session_size ) ;
	if( penv->forward_session_array == NULL )
	{
		printf( "malloc failed , errno[%d]" , errno );
		return -1;
	}
	memset( penv->forward_session_array , 0x00 , sizeof(struct ForwardSession) * penv->cmd_para.forward_session_size );
	
	pthread_mutex_init( & (penv->mutex) , NULL );
	
	return 0;
}

void CleanEnvirment( struct ServerEnv *penv )
{
	int		n ;
	
	close( penv->accept_epoll_fd );
	free( penv->forward_thread_tid_array );
	free( penv->forward_session_array );
	
	for( n = 0 ; n < penv->cmd_para.forward_thread_size ; n++ )
	{
		close( penv->forward_epoll_fd_array[n] );
	}
	
	pthread_mutex_destroy( & (penv->mutex) );
	
	return;
}

int AddListeners( struct ServerEnv *penv )
{
	int			forward_rule_index ;
	struct ForwardRule	*p_forward_rule = NULL ;
	int			forwards_addr_index ;
	
	struct ForwardSession	*p_forward_session = NULL ;
	struct epoll_event	event ;
	
	int			nret = 0 ;
	
	for( forward_rule_index = 0 ; forward_rule_index < penv->forward_rules_count ; forward_rule_index++ )
	{
		p_forward_rule = penv->forward_rules_array + forward_rule_index ;
		
		for( forwards_addr_index = 0 ; forwards_addr_index < p_forward_rule->forwards_addr_count ; forwards_addr_index++ )
		{
			if( penv->old_penv )
			{
				int		old_forward_rule_index ;
				
			}
			else
			{
				p_forward_rule->forwards_addr[forwards_addr_index].sock = socket( AF_INET , SOCK_STREAforward_rule_index , IPPROTO_TCP );
				if( p_forward_rule->forwards_addr[forwards_addr_index].sock == -1 )
				{
					ErrorLog( __FILE__ , __LINE__ , "socket failed , errno[%d]" , errno );
					return -1;
				}
				
				SetNonBlocking( p_forward_rule->forwards_addr[forwards_addr_index].sock );
				SetReuseAddr( p_forward_rule->forwards_addr[forwards_addr_index].sock );
				
				nret = bind( p_forward_rule->forwards_addr[forwards_addr_index].sock , (struct sockaddr *) & (p_forward_rule->forwards_addr[forwards_addr_index].netaddr.sockaddr) , sizeof(struct sockaddr) ) ;
				if( nret )
				{
					ErrorLog( __FILE__ , __LINE__ , "bind[%s:%d] failed , errno[%d]" , p_forward_rule->forwards_addr[forwards_addr_index].netaddr.ip , p_forward_rule->forwards_addr[forwards_addr_index].netaddr.port.port_int , _ERRNO );
					return -1;
				}
				
				nret = listen( p_forward_rule->forwards_addr[forwards_addr_index].sock , 1024 ) ;
				if( nret )
				{
					ErrorLog( __FILE__ , __LINE__ , "listen[%s:%d] failed , errno[%d]" , p_forward_rule->forwards_addr[forwards_addr_index].netaddr.ip , p_forward_rule->forwards_addr[forwards_addr_index].netaddr.port.port_int , _ERRNO );
					return -1;
				}
			}
			
			p_forward_session = GetForwardSessionUnused( penv ) ;
			if( p_forward_session == NULL )
			{
				ErrorLog( __FILE__ , __LINE__ , "GetForwardSessionUnused failed[%d]" , nret );
				return -1;
			}
			
			p_forward_session->sock = p_forward_rule->forwards_addr[forwards_addr_index].sock ;
			p_forward_session->p_forward_rule = p_forward_rule ;
			p_forward_session->status = FORWARD_SESSION_STATUS_LISTEN ;
			
			forward_rule_indexeforward_rule_indexset( & event , 0x00 , sizeof(event) );
			event.data.ptr = p_forward_session ;
			event.events = EPOLLIN | EPOLLERR | EPOLLET ;
			epoll_ctl( penv->accept_epoll_fd , EPOLL_CTL_ADD , p_forward_rule->forwards_addr[forwards_addr_index].sock , & event );
		}
	}
	
	return 0;
}

struct ForwardSession *GetForwardSessionUnused( struct ServerEnv *penv )
{
	int			forward_session_index ;
	struct ForwardSession	*p_forward_session = NULL ;
	
	for( forward_session_index = 0 , p_forward_session = penv->forward_session_array + penv->forward_session_use_offsetpos ; forward_session_index < penv->cmd_para.forward_session_size ; forward_session_index++ )
	{
		if( p_forward_session->status == FORWARD_SESSION_STATUS_UNUSED )
		{
			memset( p_forward_session , 0x00 , sizeof(struct ForwardSession) );
			p_forward_session->status = FORWARD_SESSION_STATUS_READY ;
			penv->forward_session_use_offsetpos++;
			if( penv->forward_session_use_offsetpos >= penv->cmd_para.forward_session_size )
			{
				penv->forward_session_use_offsetpos = 0 ;
			}
			return p_forward_session;
		}
		
		penv->forward_session_use_offsetpos++;
		p_forward_session++;
		if( penv->forward_session_use_offsetpos >= penv->cmd_para.forward_session_size )
		{
			penv->forward_session_use_offsetpos = 0 ;
			p_forward_session = penv->forward_session_array ;
		}
	}
	
	return NULL;
}

void SetForwardSessionUnused( struct ForwardSession *p_forward_session )
{
	if( p_forward_session->status != FORWARD_SESSION_STATUS_UNUSED )
		p_forward_session->status = FORWARD_SESSION_STATUS_UNUSED ;
	
	return;
}

void SetForwardSessionUnused2( struct ForwardSession *p_forward_session , struct ForwardSession *p_forward_session2 )
{
	if( p_forward_session->status != FORWARD_SESSION_STATUS_UNUSED )
		p_forward_session->status = FORWARD_SESSION_STATUS_UNUSED ;
	
	if( p_forward_session2->status != FORWARD_SESSION_STATUS_UNUSED )
		p_forward_session2->status = FORWARD_SESSION_STATUS_UNUSED ;
	
	return;
}
